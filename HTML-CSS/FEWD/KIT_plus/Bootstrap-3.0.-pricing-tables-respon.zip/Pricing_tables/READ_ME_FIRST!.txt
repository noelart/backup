@BOOTSTRAPTOR TEMPLATE SUPORT:
Support & commercial usage license contact: dogserega@gmail.com

-----------------
Bootstrap 3.0. 
-----------------
- templates
- themes  -----------------------------------------------
- skins  -------> on => http://www.bootstraptor.com <==
---------------------------------------------------------

Uprgader Bootstrap 3.0. online service free http://bootstrap3.kissr.com/

follow for templates updates & new releases on Twitter.com/Bootstraptor